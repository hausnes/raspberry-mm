import random

hovedst = { 
    'Norge' : 'Oslo', 
    'Sverige' : 'Stockholm',
    'Island' : 'Reykjavik',
}

print(hovedst['Norge'])

hovedst['Frankrike'] = 'Paris'

for land, by in hovedst.items():
    print(by,'er i',land)

antRiktige = 0
total = len(hovedst)
for land, by in hovedst.items():
    svar = input(f'Hva er hovedstaden i {land}? ')
    if svar == by:
        print('Bra jobbet!')
        antRiktige += 1
    else:
        print(f'Du svarte {svar}, men det er {by}.')

print("Du svarte riktig på ",antRiktige," spørsmål, av ",total," moglege.",sep="")

'''
# Korleis hente ut tilfeldig spm heilt til det er tomt?
meir = "JA"
while meir == "JA" and len(hovedst)>0:
    spm, svar = random.choice(list(hovedst.items()))
    del hovedst[spm]
    print("Landet er",spm,"...")
    brukerSvar = input("Kva er hovudstaden? ")
    if brukerSvar == svar:
        print("Riktig!")
    else:
        print("Feil...")
    # Vil du meir?
    valg = input("Vil du gjette meir? ")
    meir =  valg.upper()

    if len(hovedst) == 0:
        print("Ikkje fleire spørsmål. Lukkar program.")
        break
'''
for land, by in hovedst.items():
    print(by,'er i',land)