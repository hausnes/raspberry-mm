
for bokstav in 'Det var en gang...':
    print('-->',bokstav,'<--')


print('vvvvvvvvv')
for punkt in [4, 'hei', 7+9, '11+13', [3,4,5] ]:
    print(punkt)
    print(3 * punkt)
print('^^^^^^^^^')


for i in range(5,12):
    print(i)


# spør om et ord og skriv ut lengde. gjør det fem ganger
# skriv ut summen av lengdene
sum = 0
for i in range(1,6):
    innlestOrd = input("Skriv inn eit ord: ")
    lengde = len(innlestOrd)
    print("Lengde",lengde)
    sum += lengde
print("Sum: ",sum)