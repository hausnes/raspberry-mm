import string

alfabet = {}
for bstav in string.ascii_lowercase:
    alfabet[bstav] = 0

with open('alice.txt') as fil:
    for linje in fil:
        for tegn in linje:
            tegn = tegn.lower()
            if tegn in alfabet:
                alfabet[tegn] += 1

for bstav, tall in alfabet.items():
    print(f'{bstav}: {tall}')

alle = sum(alfabet.values())

for bstav, tall in alfabet.items():
    prosent = tall / alle * 100
    print(f'{bstav}: {prosent:4.1f} %')