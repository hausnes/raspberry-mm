print("Hei hei")
print("Velkommen!")
print()
print('Prøv å skrive noe...')
