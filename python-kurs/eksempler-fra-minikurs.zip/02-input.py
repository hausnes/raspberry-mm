print('God morgen!')

navn = input('Hva heter du? ')
print('Hyggelig å hilse på deg,',navn)

lengde = len(navn)
print('Navnet ditt har',lengde,'bokstaver.')

understrek = '-' * lengde
print(navn)
print(understrek)

print()
print()
print()

input('Kan vi gå videre? ')

a = input('Tall A: ')
b = input('Tall B: ')

#a = int(a)
#b = int(b)
print('Summen er ', a+b)

