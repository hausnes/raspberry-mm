
sted = 'Vi er i Bergen'
print(sted)

flere = 'Aaa\nBbb\nCcc'
print(flere)

print('\n' * 3)

# Hva er forskjellen her?
print(4 + 7)
print('4 + 7')

print()

x = 12
y = 20
print('x =',x)
print('y =',y)
print('y - x =',y-x)

print()

x = x + 1
y = y + 5
print('x =',x)
print('y =',y)
print('x + y =',y-x)
