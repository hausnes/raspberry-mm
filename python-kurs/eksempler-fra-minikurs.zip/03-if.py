print('Er 5 mindre enn 7?', 5 < 7)
print()

bokstav = 'a'
ordet = 'oppvaskmaskin'
resultat = bokstav in ordet

print('Finnes det',bokstav,'i',ordet,'?', resultat)

x = 5
y = 7
if x > y:
    print('X er større!')
print('===========')

tekst = 'God morgen!'
if 'a' in tekst:
    print('Funnet a')
elif ' ' in tekst:
    print('Flere ord')
elif '!' in tekst:
    print('Utropstegn')
else:
    print('Ingenting')

print('****************')


# Oppgave: spør om 3 nummer, svar hvilken er størst

#import numpy # NB: I mange tilfeller må du laste ned dette biblioteket sjølv. Fjern kommentar om du vil bruke dette
liste = []
a = int(input("Tall 1: "))
b = int(input("Tall 2: "))
c = int(input("Tall 3: "))

liste.append(a)
liste.append(b)
liste.append(c)
print(liste)

#print(numpy.max(liste)) # Kommenter ut dersom du har numpy

# Alternativt
hogste = 0
for tall in liste:
    if tall > hogste:
        hogste = tall
print("Høgste tal er:",hogste)